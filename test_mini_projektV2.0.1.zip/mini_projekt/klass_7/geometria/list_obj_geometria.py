GEOMETRIA: dict[str, dict[str, str]] = {
    "1": {
        "about": "Геометрия 7-9 класс Атанасян",
        "url": "https://gdz.ru/po-geometrii/7-klass/atanasyan",
    },
    "2": {
        "about": "Геометрия 7 класс Мерзляк Полонский Якир",
        "url": "https://gdz.ru/po-geometrii/7-klass/merzljak",
    },
    "3": {
        "about": "Геометрия 7 класс рабочая тетрадь Атанасян",
        "url": "https://gdz.ru/po-geometrii/7-klass/rabochaya-tetrad-atanasyan",
    },
    "4": {
        "about": "Геометрия 7 класс рабочая тетрадь Мерзляк Полонский",
        "url": "https://gdz.ru/po-geometrii/7-klass/rabochaya-tetrad-merzlyak-polonskij",
    },
    "5": {
        "about": "Геометрия 7 класс дидактические материалы Мерзляк А.Г.",
        "url": "https://gdz.ru/po-geometrii/7-klass/didakticheskie-materiali-merzlyak",
    },
    "6": {
        "about": "Геометрия 7 класс рабочая тетрадь Бутузов В.Ф.",
        "url": "https://gdz.ru/po-geometrii/7-klass/tetrad-butuzov",
    },
    "7": {
        "about": "Геометрия 7 класс рабочая тетрадь Мищенко Т.М.",
        "url": "https://gdz.ru/113465",
    },
    "8": {
        "about": "Геометрия 7 класс рабочая тетрадь Дудницын Ю.П.",
        "url": "https://gdz.ru/126636",
    },
}
