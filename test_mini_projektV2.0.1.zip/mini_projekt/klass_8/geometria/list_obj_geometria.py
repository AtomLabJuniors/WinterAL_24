GEOMETRIA: dict[str, dict[str, str]] = {
    "1": {
        "about": "Геометрия 8 класс рабочая тетрадь Атанасян",
        "url": "https://gdz.ru/po-geometrii/8-klass/rabochaya-tetrad-atanasyan",
    },
    "2": {
        "about": "Геометрия 8 класс Мерзляк",
        "url": "https://gdz.ru/po-geometrii/8-klass/merzkyak",
    },
    "3": {
        "about": "Геометрия 8 класс рабочая тетрадь Мерзляк А.Г.",
        "url": "https://gdz.ru/76923",
    },
    "4": {
        "about": "Геометрия 8 класс дидактические материалы Мерзляк А.Г.",
        "url": "https://gdz.ru/58043",
    },
    "5": {
        "about": "Геометрия 8 класс рабочая тетрадь Дудницын Ю.П.",
        "url": "https://gdz.ru/po-geometrii/8-klass/rabochaya-tetrad-pogorelova",
    },
    "6": {
        "about": "Геометрия 8 класс рабочая тетрадь Мищенко Т.М.",
        "url": "https://gdz.ru/108484",
    },
}
